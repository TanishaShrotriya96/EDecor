
from django.shortcuts import render,get_object_or_404
from django.views.generic import TemplateView, ListView # Import TemplateView
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.urls import reverse

from votings.models import *
from votings.forms import *

#from .model import bed
#used for saving uploaded image to static folder.
import os
#importing object detection code
#from votings.object import *
#from votings.processing import *
from django.http import HttpResponse
from .models import Category, Product 
from cart.forms import CartAddProductForm
#from .model import bed


def product_list(request, category_slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = Product.objects.filter(category=category)
    user=request.session.get('customer_name')
    #extracting session variable of current logged in user.
    context = {
        'category': category,
        'categories': categories,
        'products': products,
        'user':user
    }
    return render(request, 'polls/product/list.html', context)


def product_detail(request, id, slug):
    print("I am in product_detail")
    product = get_object_or_404(Product, id=id, slug=slug, available=True)
    cart_product_form = CartAddProductForm()
    user=request.session.get('customer_name')
    context = {
        'product': product,
        'cart_product_form': cart_product_form,
        'user':user
    }
    return render(request, 'polls/product/detail.html', context)


# Add the two views we have been talking about  all this time :)
class IndexPageView(TemplateView):

    template_name = "polls/index.html"


class CatPageView(TemplateView):
    template_name = "polls/cat.html"

def uploadRoom(request):
    # Handle file upload
    print("I am inside uploadRoom")
    form = DocumentForm() # A empty, unbound form
    print("Created a Document Form")
    if(request.method == 'POST'):

        print("POST request received")
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            print("Form is valid")
            customer_id=request.session.get('customer_id')
            roomImage = Document(docfile = request.FILES['docfile'],
                customer_id=customer_id)
            roomImage.save()
            print("Room Image Path is: ", roomImage.docfile.path)
            #processRoom=ProcessRoomImage()
            #processRoom.DetectObjects(roomImage.docfile.path)
            oldName=roomImage.docfile.path
            newName=os.getcwd()+"/static/users/"+roomImage.docfile.name
            os.rename(oldName,newName)
            file=roomImage.docfile.name
            request.session['currentRoom']=file
            print(file)
            print("New Path is: "+newName)
            document = roomImage
            print(document)
            # Redirect to the document list after POST
            #return HttpResponseRedirect(reverse('list1'))
            return render(request, 'polls/uploadRoom.html', {'document': document, 'form': form},)
    # Load documents for the list page

    
    #call object detector here
    #print("When inside list1 customer_id is: ", customer_id)
    #print("When inside list1: ", password)

    # print(documents)
    # Render list page with the documents and the form
    print("POST NOT received")
    return render(request, 'polls/uploadRoom.html', { 'form': form},)

def login(request):
    print("here")
    if(request.method =='POST'):
         print("CONNECTED TO LOGIN")
         username= request.POST.get('user')
         password= request.POST.get('password')
         customer_obj=CustomerDetails.objects.get(
                      name=username,password=password)
         print(customer_obj,"Counting total users: ",customer_obj)
         if(customer_obj): 
             print("Name Matched")
             customer_id=customer_obj.id
             #setting session variables for the logged in session
             request.session['customer_id']=customer_id
             request.session['customer_name']=customer_obj.name
             print("When inside login customer_id is : ", customer_id)
             print("Now rendering list.html")
             return render(request, 'polls/uploadRoom.html')
    else:
        return render(request, 'polls/index.html')

def logout(request) :
    print("I am in logout")
    if(request.method == 'POST'):
        request.session.flush()
    return render(request, 'polls/index.html')

'''#from django.shortcuts import render
#from django.template.loader import get_template
# Create your views here.
#from django.http import HttpResponse


#def index(request):
 #   return HttpResponse("Hello, world. You're at the polls index.")

#def basefunc(request):
#	b = get_template('polls/login.html')
#	html = b.render({'shubhangi':'hi'})
#	return HttpResponse(html)
    #return HttpResponse("Hello, world. You're at the polls index.")'''


