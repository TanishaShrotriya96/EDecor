from votings.object import *

class ProcessRoomImage:
  #===================================================
  #Loading single image and detecting objects
  def DetectObjects(self,roomImage):
    
    images=Image.open(roomImage) 
    print("Image is as follows : \n\n\n")
    #images.show() 
    detector=ObjectDetection() 
    print(images.size)
      # the array based representation of the image will be used later in order to prepare the
      # result image with boxes and labels on it.
    image_np = detector.load_image_into_numpy_array(images)
      # Expand dimensions since the model expects images to have shape: [1, None, None, 3]
    image_np_expanded = np.expand_dims(image_np, axis=0)
      # Actual detection.
    output_dict = detector.run_inference_for_single_image(image_np, detection_graph)
    vis_util.visualize_boxes_and_labels_on_image_array(
          image_np,
          output_dict['detection_boxes'],
          output_dict['detection_classes'],
          output_dict['detection_scores'],
          category_index,
          instance_masks=output_dict.get('detection_masks'),
          use_normalized_coordinates=True,
          line_thickness=8)

    print("\n\nDetected objects: ")
   # plt.figure(figsize=IMAGE_SIZE)
   # plt.save(os.getcwd()+"/static/users/cache")
    #plt.imshow(image_np)

    print("\n\nCoordinates of detected objects")
    coordinates=output_dict['detection_boxes'][:5]
    print(coordinates)
    print(type(coordinates))

