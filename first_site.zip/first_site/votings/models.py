from django.db import models

# Create your models here.
'''class Product(models.Model):
	title       = models.CharField(max_length=120)
	description = models.TextField(blank=TRUE, null=TRUE)
	price       = models.DecimalField(decimal_places=2, max_digits=10000)
	summary     = models.TextField(blank=FALSE, null=FALSE)
	featured    = models.BooleanField()

   class bed(models.Model):
   		id = models.IntegerField(max_length=4)
   		type = models.CharField(max_length=20)
   		path = models.CharField(max_length=100)


   		def _str_(self):
   			return self.path'''

