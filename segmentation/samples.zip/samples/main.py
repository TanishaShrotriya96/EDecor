import processing
import object

def main():
       
    choice="yes"   
    while(choice==yes):   
    # load the image of room and detect the objects.
    processRoom=ProcessRoomImage()
    detected_objs=processRoom.DetectObjects(request.FILES['docfile'])
    print(detected_objs)
    
    #extract the objects from room.
    objects=processRoom.ObjectExtraction(detected_objs,request.FILES['docfile'])

    #return style of the objects.
    styles=processRoom.LoadStylizer(objects)
    print(styles)
    #styles is a list of tuples
    #so we sort based on second value in each tuple so key =x[1]
    #and we want it to e in descending order
    styles=sorted(styles,key=lambda x: x[1], reverse=True)
    print(styles)
    #saving the style of user.
    style1=styles[0][0]
    style2=styles[1][0]

    choice=str(input(("Enter name of file =>")))
            