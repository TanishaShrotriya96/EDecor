from django.shortcuts import render
from django.views.generic import TemplateView, ListView # Import TemplateView
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.urls import reverse

from votings.models import Document
from votings.forms import DocumentForm

#from .model import bed

# Add the two views we have been talking about  all this time :)
class IndexPageView(TemplateView):
    template_name = "polls/index.html"


class CatPageView(TemplateView):
    template_name = "polls/cat.html"


#class ListPageView(TemplateView):
    #template_name = "polls/list.html"

def list(request):
    # Handle file upload
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            newdoc = Document(docfile = request.FILES['docfile'])
            newdoc.save()

            # Redirect to the document list after POST
            return HttpResponseRedirect(reverse('list'))
    else:
        form = DocumentForm() # A empty, unbound form

    # Load documents for the list page
    documents = Document.objects.all()

    # Render list page with the documents and the form
    return render(request,
        'polls/list.html',
        {'documents': documents, 'form': form},
        #context_instance=RequestContext(request)
    )








'''#from django.shortcuts import render
#from django.template.loader import get_template
# Create your views here.
#from django.http import HttpResponse


#def index(request):
 #   return HttpResponse("Hello, world. You're at the polls index.")

#def basefunc(request):
#	b = get_template('polls/login.html')
#	html = b.render({'shubhangi':'hi'})
#	return HttpResponse(html)
    #return HttpResponse("Hello, world. You're at the polls index.")'''


