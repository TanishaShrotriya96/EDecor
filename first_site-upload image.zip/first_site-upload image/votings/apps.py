from django.apps import AppConfig


class VotingsConfig(AppConfig):
    name = 'votings'
