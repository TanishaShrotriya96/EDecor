# -*- coding: utf-8 -*-
from django.db import models
from django.urls import reverse

class Document(models.Model):
    docfile = models.FileField()

